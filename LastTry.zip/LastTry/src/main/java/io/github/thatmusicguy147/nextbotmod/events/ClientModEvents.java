package io.github.thatmusicguy147.nextbotmod.events;

import io.github.thatmusicguy147.nextbotmod.Nextbotmod;
import io.github.thatmusicguy147.nextbotmod.client.model.NextbotModel;
import io.github.thatmusicguy147.nextbotmod.client.renderer.NextbotEntityRenderer;
import io.github.thatmusicguy147.nextbotmod.entity.NextbotEntity;
import io.github.thatmusicguy147.nextbotmod.init.NextbotInit;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = Nextbotmod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ClientModEvents {
    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event)
    {
        EntityRenderers.register(NextbotInit.NEXTBOT.get(), NextbotEntityRenderer::new);
    }

    @SubscribeEvent
    public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event)
    {
        event.registerLayerDefinition(NextbotModel.LAYER_LOCATION, NextbotModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void registerEntityAttributes(EntityAttributeCreationEvent event)
    {
        System.out.println("Registering attributes for NextbotEntity");
        event.put(NextbotInit.NEXTBOT.get(), NextbotEntity.createAttributes().build());
    }

}
