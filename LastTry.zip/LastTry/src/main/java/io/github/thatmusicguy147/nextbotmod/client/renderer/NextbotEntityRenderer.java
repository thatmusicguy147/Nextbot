package io.github.thatmusicguy147.nextbotmod.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import io.github.thatmusicguy147.nextbotmod.Nextbotmod;
import io.github.thatmusicguy147.nextbotmod.client.model.NextbotModel;
import io.github.thatmusicguy147.nextbotmod.entity.NextbotEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.joml.Vector3f;
import com.mojang.math.Axis;

public class NextbotEntityRenderer extends MobRenderer<NextbotEntity, NextbotModel<NextbotEntity>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(Nextbotmod.MODID,
            "textures/entity/nextbot.png");

    public NextbotEntityRenderer(EntityRendererProvider.Context context)
    {
        super(context, new NextbotModel<>(context.bakeLayer(NextbotModel.LAYER_LOCATION)), 2.0F);

    }

    @Override
    public ResourceLocation getTextureLocation(NextbotEntity entity)
    {
        return TEXTURE;
    }

    @Override
    protected void setupRotations(NextbotEntity entity, PoseStack poseStack, float ageInTicks, float rotationYaw, float partialTicks)
    {
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - rotationYaw));
    }

    @Override
    public void render(NextbotEntity entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        float scale = 8.0F; // Scale factor (2x bigger)
        poseStack.scale(scale, scale, scale); // Scale the model
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
        poseStack.popPose();
    }
}
