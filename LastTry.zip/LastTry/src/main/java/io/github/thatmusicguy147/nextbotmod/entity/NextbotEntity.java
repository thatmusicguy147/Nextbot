package io.github.thatmusicguy147.nextbotmod.entity;

import io.github.thatmusicguy147.nextbotmod.init.NextbotInit;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.ServerLevelAccessor;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class NextbotEntity extends Monster {

    private int soundCooldown = 0;
    private final AtomicBoolean isSoundPlaying = new AtomicBoolean(false);
    private ScheduledExecutorService scheduler;

    public NextbotEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0, false));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 1.0));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 300.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.ATTACK_DAMAGE, 15.0)
                .add(Attributes.FOLLOW_RANGE, 50000.0);
    }

    public static boolean checkNextbotSpawnRules(EntityType<NextbotEntity> type, ServerLevelAccessor level, MobSpawnType spawnType, BlockPos pos, RandomSource random) {
        System.out.println("Attempting to spawn Nextbot at: " + pos);
        return level.getBrightness(LightLayer.SKY, pos) <= 7 &&
                level.getBrightness(LightLayer.BLOCK, pos) <= 7 &&
                Mob.checkMobSpawnRules(type, level, spawnType, pos, random);
    }

    @Override
    public void tick() {
        super.tick();

        if (!this.level().isClientSide && !isSoundPlaying.get())
        {
            startSoundLoop();
        }
    }

    private void startSoundLoop()
    {
        if (!isSoundPlaying.compareAndSet(false, true))
        {
            return;
        }

        scheduler = Executors.newSingleThreadScheduledExecutor();

        scheduler.scheduleAtFixedRate(() -> {
            if (!this.isRemoved() && this.isAlive()) {
                this.level().playSound(
                        null,
                        this.getX(),
                        this.getY(),
                        this.getZ(),
                        NextbotInit.SELENE_DELGADO_SOUND.get(),
                        SoundSource.HOSTILE,
                        1.0F,
                        1.0F
                );
            } else {
                stopSoundLoop();
            }
        }, 0, 20, TimeUnit.SECONDS);


    }

    private void stopSoundLoop()
    {
        if (scheduler != null)
        {
            scheduler.shutdown();
            scheduler = null;
            isSoundPlaying.set(false);
        }
    }

    @Override
    public void remove(RemovalReason reason)
    {
        stopSoundLoop();
        super.remove(reason);
    }
}


