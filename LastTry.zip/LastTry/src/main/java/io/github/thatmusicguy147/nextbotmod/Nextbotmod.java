package io.github.thatmusicguy147.nextbotmod;

import io.github.thatmusicguy147.nextbotmod.init.NextbotInit;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(Nextbotmod.MODID)
public class Nextbotmod {
    public static final String MODID = "nextbotmod";

    public Nextbotmod()
    {
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::commonSetup);
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::clientSetup);
        NextbotInit.init();
    }

    private void commonSetup(final FMLCommonSetupEvent event)
    {
        event.enqueueWork(NextbotInit::registerSpawnPlacement);

    }

    private void clientSetup(final FMLClientSetupEvent event)
    {

    }
}
