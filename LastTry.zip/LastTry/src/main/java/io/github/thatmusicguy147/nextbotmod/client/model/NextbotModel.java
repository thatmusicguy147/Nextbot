package io.github.thatmusicguy147.nextbotmod.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import io.github.thatmusicguy147.nextbotmod.Nextbotmod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;

public class NextbotModel<T extends Entity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(Nextbotmod.MODID, "nextbot"), "main");
    private final ModelPart billboard;

    public NextbotModel(ModelPart root)
    {
        this.billboard = root.getChild("billboard");
    }

    public static LayerDefinition createBodyLayer()
    {
        MeshDefinition meshDefinition = new MeshDefinition();
        PartDefinition partDefinition = meshDefinition.getRoot();
        partDefinition.addOrReplaceChild("billboard", CubeListBuilder.create()
                .texOffs(0, 0)
                .addBox(-8, 0, -0.1f, 16, 16, 0.2f)
                , PartPose.ZERO);
        return LayerDefinition.create(meshDefinition, 16, 16);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float needHeadYaw, float headPitch)
    {

    }

    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha)
    {
        billboard.render(poseStack, buffer, packedLight, packedOverlay);
        poseStack.pushPose();
        poseStack.scale(4.0F, 4.0F, 4.0F);
        poseStack.popPose();

    }
}
