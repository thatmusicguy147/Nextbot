package io.github.thatmusicguy147.nextbotmod.init;

import io.github.thatmusicguy147.nextbotmod.Nextbotmod;
import io.github.thatmusicguy147.nextbotmod.entity.NextbotEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class NextbotInit {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, Nextbotmod.MODID);

    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, "nextbotmod");

    public static final RegistryObject<SoundEvent> SELENE_DELGADO_SOUND = SOUNDS.register("selene_delgado_sound",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("nextbotmod", "selene_delgado_sound")));

    public static final RegistryObject<EntityType<NextbotEntity>> NEXTBOT = ENTITIES.register("nextbot",
            () -> EntityType.Builder.of(NextbotEntity::new, MobCategory.MONSTER)
                    .sized(2.4F, 7.8F)
                    .build(new ResourceLocation(Nextbotmod.MODID, "nextbot").toString()));

    public static void init()
    {
        ENTITIES.register(FMLJavaModLoadingContext.get().getModEventBus());
        SOUNDS.register(FMLJavaModLoadingContext.get().getModEventBus());
    }

    public static void registerSpawnPlacement()
    {
        if(NEXTBOT.isPresent())
        {
            SpawnPlacements.register(
                    NEXTBOT.get(),
                    SpawnPlacements.Type.ON_GROUND,
                    Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                    NextbotEntity::checkNextbotSpawnRules);
        }

        else
        {
            System.err.println("Nextbot EntityType is not registered!");
        }
    }
}

